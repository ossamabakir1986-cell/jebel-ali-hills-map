Hayat Luxury GIS - Full Website Export
Generated: 7/10/2026, 2:13:11 PM

This ZIP is the full website package for GitHub.

How to use:
1. Extract this ZIP.
2. Delete/clear the old GitHub repository files if needed.
3. Upload the extracted folders/files, not the ZIP itself.
4. Keep data files inside the js folder. Do not place them in the root folder.

Included live inventory records: 558
Included data files:
- js/admin_inventory_data.js
- js/agent_inventory_data.js
- js/published_inventory_data.js

Warning: these static files could not be fetched from this page and were not included:
- README_HAYAT_GIS_V3_STABLE.txt
- README_SETTINGS_SYNC_FIX.txt
- README_V3_0_3_DETAILS_SYNC_FIX.txt
- README_V3_1_STABLE.txt

If you opened the page by double-clicking the HTML file, use the GitHub Pages link or a local server, then export again.
