Hayat Luxury GIS - Jebel Ali Hills
Version: v3.3.20 Clean Fast Filters + Features

Purpose:
This package fixes the issue where Admin/Agent filters were unresponsive and the console showed many ERR_FILE_NOT_FOUND errors.

Root cause found:
admin.html and agent.html were still referencing old JavaScript patch files that were no longer present in the website package:
- js/v32_enhancements.js
- js/performance_core.js
- js/v331_feature_pa_fixes.js
- js/v332_feature_label_fix.js
- js/v334_stable_core_fix.js
- js/v335_pa_handle_offset_fix.js
- js/v336_add_inventory_fix.js
- js/v337_add_inventory_pins_light.js
- js/v338_add_inventory_click_fix.js
- js/v339_unified_pa_add_inventory.js
- js/v3311_add_inventory_details_recalc_fix.js
- js/v3312_unified_pa_label_click_final_fix.js
- js/v3316_filter_engine_rebuild_verified.js
- js/v3317_move_plot_handle_and_light_pa_labels.js
- js/v3318_smoother_filters_default_hidden_pa_labels.js

Fixes in this package:
- Removed missing old script references.
- Added one final consolidated script: js/v3320_clean_fast_filters_features.js
- Restored fast Admin and Agent filters.
- Added Features filter back to Admin and Agent.
- Added Features to Details checklist.
- Added Features display in plot popup.
- Added Features field in Admin Edit Plot form.
- Master Plan PA labels remain OFF on startup.
- PA labels are transparent/light text-only when enabled.
- PA labels render only inside visible map area.
- Red / Blue / Pink / Other inventory visibility is forced ON by default to avoid hidden agent stock from old published settings.
- Move Plot handle remains offset to the side with a gold exact-coordinate anchor dot.

Upload instructions:
Delete the old GitHub files/folders, then upload this full package:
- assets
- css
- js
- admin.html
- agent.html
- index.html

After upload:
- Wait 1-2 minutes for GitHub Pages.
- Open admin.html and agent.html.
- Press Ctrl + Shift + R once.
- The count box should show: Filters: v3.3.20 Clean Fast Filters + Features
