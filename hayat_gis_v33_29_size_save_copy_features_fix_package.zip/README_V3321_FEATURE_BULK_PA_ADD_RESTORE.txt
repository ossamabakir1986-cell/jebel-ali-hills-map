Hayat Luxury GIS - Jebel Ali Hills
Version: v3.3.21 Feature Bulk + PA Add Restore

Built on v3.3.20 clean fast filters.

Restored / fixed:
- Admin plot editor now has standard feature checkboxes again.
- Features can be added when pressing/editing a plot.
- Features are saved into the plot inventory data.
- Bulk edit selected plots restored for features and key fields.
- Bulk feature actions: append feature, replace all features, clear features.
- Master Plan PA labels remain OFF by default for performance.
- When Master Plan PA labels are turned ON in Admin, clicking an empty PA label opens Add Inventory directly.
- PA labels are transparent/light, with only the number colored, and have a larger invisible hit area for easier clicking.
- Fast filters from v3.3.20 are preserved.

Clean upload required:
Delete old assets/css/js folders and admin.html/agent.html/index.html from GitHub, then upload this full package.
After upload, open the map and press Ctrl + Shift + R once.
