Hayat GIS v3.3.22 - PA Alignment + Move Plot Restore

Built on v3.3.21.

Fixes:
- Restores original Master Plan / PA label anchoring so labels align with the HD master plan again.
- Keeps PA labels transparent/text-only.
- Keeps PA labels OFF by default.
- Keeps Admin empty PA label click -> Add Inventory.
- Restores Move Plot with a side drag handle, gold exact-coordinate dot, and save/cancel controls.
- Keeps v3.3.21 feature editor and bulk feature tools.
- Keeps fast filters from v3.3.20/v3.3.21.

Upload as a full clean replacement: assets, css, js, admin.html, agent.html, index.html.
After upload use Ctrl+Shift+R once.
