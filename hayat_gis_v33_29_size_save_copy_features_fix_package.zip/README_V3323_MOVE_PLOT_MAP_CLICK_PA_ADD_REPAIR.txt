Hayat Luxury GIS - Jebel Ali Hills
v3.3.23 Move Plot Map Click + PA Add Repair

Built from v3.3.22.

Purpose:
- Keep the v3.3.20 clean fast filters.
- Keep the v3.3.21 feature editor and bulk feature tools.
- Keep transparent PA labels and PA labels OFF by default.
- Repair Move Plot so it is clear and usable.
- Repair clicking empty Master Plan PA labels to add new inventory.

Move Plot workflow:
1. Open an existing plot.
2. Click Move Plot.
3. A green side handle and gold exact-coordinate dot appear.
4. Either drag the green side handle OR click the exact new location directly on the map.
5. The gold dot is the coordinate that will be saved.
6. Click Save Position.
7. Export Updated Data / Full Website Package after changes.

PA Add workflow:
1. Turn ON Master Plan PA labels.
2. Empty master-plan PA labels are clickable in Admin.
3. Click an empty PA label to open Add Inventory.

Notes:
- Agent map is not changed for editing tools.
- No missing old script references should be required.
