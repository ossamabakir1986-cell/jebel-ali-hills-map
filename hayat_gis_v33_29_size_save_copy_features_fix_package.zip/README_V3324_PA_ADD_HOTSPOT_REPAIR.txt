Hayat Luxury GIS - Jebel Ali Hills
Version: v3.3.24 PA Add Inventory Hotspot Repair

Built from: v3.3.23 Move Plot Map Click + PA Add Repair

Purpose:
- The visible Master Plan PA labels stayed aligned, but clicking an empty PA label was still unreliable.
- This version adds a separate invisible admin-only clickable hotspot layer for empty Master Plan PA labels.
- The visible PA label alignment is not moved.

How to use Add Inventory from PA label:
1. Open admin.html.
2. Tick: Master Plan PA labels.
3. Click an empty Master Plan PA label that is not already in inventory.
4. A small + Add hover hint may appear.
5. The Add Plot editor opens with GIS Plot, Master Plan Plot, Phase, and coordinates filled automatically.
6. Complete agent/price/status/type/features and click Add Plot.

Important:
- Existing inventory labels/pins do not open Add Inventory. They open normal plot details/editing.
- Agent map remains non-editable; add inventory is admin-only.

Preserved from previous versions:
- Fast filters and agent filter.
- Feature filter.
- Add/edit features on plot press.
- Bulk feature editing for selected plots.
- PA labels OFF by default.
- Transparent PA label style.
- Move Plot by map click or green side handle.
- Export Updated Data and Export Full Website Package.
