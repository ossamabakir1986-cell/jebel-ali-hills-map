Hayat GIS v3.3.25 - Visible PA Add Badges Final

Purpose:
- Fix the Add Inventory from empty Master Plan PA labels workflow by making the clickable action visible.

How it works in Admin map:
1. Open admin.html.
2. Turn ON "Master Plan PA labels".
3. Empty master-plan plots now show a gold "+ Add" badge beside the PA number.
4. Click the gold "+ Add" badge.
5. The Add Plot editor opens with the PA number and coordinate prefilled.

Fixes included:
- v3.3.24 hotspot script is now actually loaded.
- v3.3.25 visible add-badge script is loaded last.
- Password gate document.write was cleaned so it no longer contains an embedded script tag.
- Add badges are Admin-only; Agent map remains view-only.
- Existing filters, Move Plot, PA label alignment, features, and bulk feature editing are preserved.
