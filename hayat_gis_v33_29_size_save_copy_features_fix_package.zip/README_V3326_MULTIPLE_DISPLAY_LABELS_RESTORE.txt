Hayat GIS v3.3.26 - Multiple Display Labels Restore

Built on v3.3.25 Visible PA Add Badges Final.

Restored:
- Multiple display-label checkbox workflow on Admin and Agent maps.
- Users can show more than one inventory label at the same time, such as:
  Master Plan + Price/sqft + Agent, or GIS + Master Plan + Features.
- Two-offer label mode restored:
  cheapest, direct, both, primary.

Preserved from v3.3.25:
- Gold + Add badges for empty Master Plan PA labels in Admin.
- PA labels transparent/text-only.
- Agent map remains view-only.
- Working filters and agent filter.
- Feature filter, plot feature editing, bulk feature editing.
- Move Plot tool.
- Export Updated Data and Export Full Website Package.

After uploading to GitHub, hard refresh once with Ctrl + Shift + R.
