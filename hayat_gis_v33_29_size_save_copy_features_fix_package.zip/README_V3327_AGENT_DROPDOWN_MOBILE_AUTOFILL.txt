Hayat GIS v3.3.27 - Agent Dropdown + Mobile Autofill Restore

Based on v3.3.26 Multiple Display Labels Restore.

Restored Admin Add/Edit workflow:
- In Add Plot / Add Inventory, Agent now uses the saved agent list from inventory data.
- Choosing an agent auto-fills the Mobile field.
- Second Agent also uses the same list and auto-fills Second Mobile.
- Manual typing is still allowed if a new agent is not in the list.
- Existing filters, multiple display labels, + Add PA badges, Move Plot, PA alignment, bulk features, and exports are preserved.

Extra export fix:
- Export Full Website Package now includes the new v3320-v3327 final scripts, so exported GitHub packages do not lose features after export.

Upload as a full clean replacement:
assets, css, js, admin.html, agent.html, index.html
Then hard refresh with Ctrl + Shift + R.
