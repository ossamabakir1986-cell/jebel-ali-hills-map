Hayat GIS v3.3.28 - Size Slot Restore

Restores the Size / Area sqft field inside the Admin Add/Edit Plot editor.

Fixed:
- Add Plot now shows Size / Area sqft.
- Edit Plot now shows existing plot size.
- Save/Add Plot now writes the size value back into the inventory record.
- Financial calculations use the saved size again for Total, Deposit, Commission, Second Offer calculations, and GFA allowed.

Preserved from v3.3.27:
- Agent dropdown + mobile autofill.
- Second agent dropdown + mobile autofill.
- Multiple display labels.
- Gold + Add PA badges.
- Feature checkboxes and bulk feature editing.
- Move Plot.
- Transparent PA labels.
- Fast filters.
