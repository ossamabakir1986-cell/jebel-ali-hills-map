Hayat GIS v3.3.29 - Size Save + Copy Text Fix

Built from saved stable baseline v3.3.28 Size Slot Restore.

Fixes:
- New plot Size / Area sqft value now saves into the inventory record.
- Size-based calculations are refreshed after saving: total, deposit, commission, second-offer total, and GFA allowed.
- Copy Description no longer includes the color/status sentence.
- Copy Details and Copy Description now include plot Features when available.
- Copy Selected Details and Copy Selected Description also include available features.

Preserved from v3.3.28:
- Agent dropdown + mobile autofill.
- Second agent dropdown + mobile autofill.
- Multiple display labels.
- Gold + Add PA badges.
- Features and bulk feature editing.
- Move Plot.
- Transparent PA labels.
- Fast filters.
- Agent map view-only.
